
package oopcw;
import java.util.Date;

/**
 * This class creates a delivery
 * @author 50057876
 * @Since 5/5/23
 */
public class Delivery {
    //Variables
    private String customer;
    private Date deliveryDate;
    private String medication;
    private String confirmationCode;
    
    //Constructor

    /**
     * Constructor for Delivery class
     * @param customer - String
     * @param deliveryDate - Date
     * @param medication - String
     * @param confirmationCode - String
     */
    public Delivery(String customer, Date deliveryDate, String medication, String confirmationCode){
        this.customer = customer;
        this.deliveryDate = deliveryDate;
        this.medication = medication;
        this.confirmationCode = confirmationCode;
    }
    
    //Setters

    /**
     * A setter method to update the delivery customer
     * @param customer - String
     */
    public void setCustomer(String customer){
        this.customer = customer;
    }
    
    /**
     * A setter method to update the delivery date
     * @param deliveryDate - Date
     */
    public void setDeliveryDate(Date deliveryDate){
        this.deliveryDate = deliveryDate;
    }
    
    /**
     * A setter method to update the delivery medication
     * @param medication - String
     */
    public void setMedication(String medication){
        this.medication = medication;
    }
    
    /**
     * A setter method to update the delivery confirmation code
     * @param confirmationCode - String
     */
    public void setConfirmationCode(String confirmationCode){
        this.confirmationCode = confirmationCode;
    }
    
    //Getters

    /**
     * A getter method to return the delivery customer
     * @return String
     */
    public String getCustomer(){
        return customer;
    }
    
    /**
     * A getter method to return the delivery date
     * @return Date
     */
    public Date getDeliveryDate(){
        return deliveryDate;
    }
    
    /**
     * A getter method to return the delivery medication
     * @return String
     */
    public String getMedication(){
        return medication;
    }
    
    /**
     * A getter method to return the delivery confirmation code
     * @return String
     */
    public String getConfirmationCode(){
        return confirmationCode;
    }
}
