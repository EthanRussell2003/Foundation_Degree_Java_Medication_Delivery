
package oopcw;

public class AppLib {
    //Customer Variables
    public static int custCount = 0, nameCheck = 0, dobCheck = 0, postcodeCheck = 0, addressCheck = 0, cityCheck = 0;
    
    public static Customer[] customers =  new Customer[20];
    public static String[] custNames =  new String[20];
    
    //Delivery Variables
    public static String customer = "";
    public static int dateCheck = 0;
    
    public static int delCount = 0;
    
    public static Delivery[] deliveries = new Delivery[20];
    public static String[] delList = new String[20];
    
    //Forms
    public static frmDelivery createDel = new frmDelivery();
    public static frmHome createHome= new frmHome();
    public static frmRegister createReg = new frmRegister();
    public static frmView createView = new frmView();
}
