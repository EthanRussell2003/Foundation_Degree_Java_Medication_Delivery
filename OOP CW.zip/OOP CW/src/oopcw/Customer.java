
package oopcw;
import java.util.Date;

/**
 * This class creates a customer
 * @author 50057876
 * @since 5/5/23
 */
public class Customer {
    //Variables
    private String name;
    private String address;
    private String postcode;
    private String city;
    private Date dateOfBirth; 
    private String gender;
    
    //Constructor

    /**
     * Constructor for Customer class
     * @param name - String
     * @param address -  String
     * @param postcode - String
     * @param city - String
     * @param dateOfBirth - Date
     * @param gender - String
     */
    public Customer(String name, String address, String postcode, String city, Date dateOfBirth, String gender){
        this.name = name;
        this.address = address;
        this.postcode = postcode;
        this.city = city;
        this.dateOfBirth = dateOfBirth;
        this.gender = gender;
    }
    
    //Setters

    /**
     * A setter method to update the customer name
     * @param name -  String
     */
    public void setName(String name){
        this.name = name;
    }
    
    /**
     * A setter method to update the customer address
     * @param address - String
     */
    public void setAddress(String address){
        this.address = address;
    }
    
    /**
     * A setter method to update the customer postcode
     * @param postcode - String
     */
    public void setPostcode(String postcode){
        this.postcode = postcode;
    }
    
    /**
     * A setter method to update the customer city
     * @param city - String
     */
    public void setCity(String city){
        this.city = city;
    }
    
    //Getters

    /**
     * A getter method to return a customer name
     * @return String
     */
    public String getName(){
        return name;
    }
    
    /**
     * A getter method to return a customer address
     * @return String
     */
    public String getAddress(){
        return address;
    }
    
    /**
     * A getter method to return a customer postcode
     * @return String
     */
    public String getPostcode(){
        return postcode;
    }
    
    /**
     * A getter method to return a customer city
     * @return String
     */
    public String getCity(){
        return city;
    }
    
    /**
     * A getter method to return a customer date of birth
     * @return Date
     */
    public Date getDateOfBirth(){
        return dateOfBirth;
    }
    
    /**
     * A getter method to return a customer gender
     * @return String
     */
    public String getGender(){
        return gender;
    }
}